<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Selesai Mebuat Web Gratis | 404</title>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Poppins&display=swap');

        body{
        display: grid;
        place-items: center;
        text-align: center;
        background: linear-gradient(-45deg, #FF0080, #388AE8, #F6FF73, #73F6FF);
        background-size: 400% 400%;
        animation: gradient 20s ease infinite;
        }
        @keyframes gradient {
            0% {
                background-position: 0% 50%;
            }
            50% {
                background-position: 100% 50%;
            }
            100% {
                background-position: 0% 50%;
            }
        }
</style>
</head>
<body>
<body>
		<div class="result">
	 <img src="" style="width: 100%; display: block; margin: auto;">
	 <div>
	 
<div class="panel">
    <h2>Order Jasteb </h2>
       <br>
          </br>
    
    <div class="button-group">
        <button onclick="short1()">⎘ Order ⎘</button>
        </div>
    </div>
</div>

<script>
    function short1() {
        window.location = 'https://wa.me/6289524433306';
    }
    
        
</script>

</body>
</html>
